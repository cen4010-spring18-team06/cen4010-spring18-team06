<?php
session_start();
?>

<?php
$servername = "localhost";
$username = "CEN4010_S2018g06";
$password = "cen4010_s2018";
$dbname = "CEN4010_S2018g06";
$znumber = $_POST['znumber'];
$userpassword = $_POST['password'];
$password_hash = password_hash($userpassword, PASSWORD_DEFAULT);

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "select * from users where znumber = '".$znumber."' ";
$sql2 = "select times from users where znumber = '".$znumber."'";
$sql4 = "select type from users where znumber = '".$znumber."'";
$sql5 = "select name from users";
$result = $conn->query($sql);
$result2 = $conn->query($sql2);
$result4 = $conn->query($sql4);
$result5 = $conn->query($sql5);
$names = array();
$uinfo = $result->fetch_assoc();


$_SESSION['Username'] = $uinfo["name"];
$_SESSION['Time'] =  $uinfo["times"];
$_SESSION['Type'] = $uinfo["type"];

$_SESSSION['TableNum'];
$_SESSION['RoomNum'];
$_SESSION['TableType'];
$_SESSION['UsedTables'];
$usedtables = array();

while($row = $result5->fetch_array()){
    $names[] = $row['name'];
}

$_SESSION['AllUsers'] = $names;

if($_SESSION['Type'] == "Student")  
{
    header('Location: student.php');
}
else if($_SESSION['Type'] == "Admin")
{
    header('Location: admin.php');
}

function resettime()
{
    $sql3 = "update users set time = " . time() . " where znumber = '".$znumber."'";
    $conn->query($sql3);
}
/*
if ($result->num_rows > 0) {
    // output data of each row    
    $row2 = $result2->fetch_assoc();
    while($row = $result->fetch_assoc()) {
        echo "Login Successful!<br>Your Name: " . $_SESSION['Username']. "<br>";
        echo "Current Time: ".time()."<br>MySQL Time: ".$_SESSION['Time']."<br>";
        echo "Type: " .$_SESSION['Type']."<br>";
        if(time() > $row2["times"] + 1800)
        {
            echo "Session time is up Start new session?<br><form action='called.php' method='POST'><input type='submit' class='button' name='reset' value='resettime' /><input type='text' name='znumber' value='". $znumber ."' /></form>";
        }
        else {
            echo (1800-(time() - $row2["times"]))/60 . " minutes remaining";
        }
    }
} else {
    echo "Login Failed!";
    echo "<script>setTimeout(\"location.href = '../index.html ';\",1500);</script>";
}
*/
$conn->close();
?>
