<?php require "../header.php"; ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">     
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="../bootstrap/js/bootstrap.min.js"></script>
        <link rel="icon" href="favicon.ico">
        <script>
            function relocate_home()
            {
                location.href = "logout.php";
            } 
        </script>
        <title>Student Page</title>
        <!-- Bootstrap core CSS -->
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>
        <h1>Student Page</h1>
        <button type="button" class="btn btn-outline-primary" onclick="relocate_home()">Logout</button>
    </body>
</html>
